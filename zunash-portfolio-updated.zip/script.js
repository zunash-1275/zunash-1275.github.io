const menu = document.querySelector('.menu');
const nav = document.querySelector('nav');
menu?.addEventListener('click', () => {
  nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
  nav.style.position = 'absolute';
  nav.style.top = '76px';
  nav.style.right = '24px';
  nav.style.flexDirection = 'column';
  nav.style.background = '#0a1220';
  nav.style.padding = '18px';
  nav.style.border = '1px solid rgba(151,181,220,.16)';
  nav.style.borderRadius = '10px';
});
document.querySelectorAll('nav a').forEach(a => a.addEventListener('click', () => {
  if (window.innerWidth <= 800) nav.style.display = 'none';
}));
