Open index.html in a browser. Replace/add your public email when ready.
The site intentionally avoids invented achievements, projects, grades, or research experience.
